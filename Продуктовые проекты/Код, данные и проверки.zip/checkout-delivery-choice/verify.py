"""Reproduce the three checkout scenarios with Chromium and Playwright."""
import argparse
from contextlib import contextmanager
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from urllib.parse import quote

from playwright.sync_api import expect, sync_playwright


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass


@contextmanager
def serve(path):
    handler = partial(QuietHandler, directory=path.parent)
    with ThreadingHTTPServer(("127.0.0.1", 0), handler) as server:
        thread = Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            yield f"http://127.0.0.1:{server.server_port}/{quote(path.name)}"
        finally:
            server.shutdown()
            thread.join()


def button(page, name):
    return page.get_by_role("button", name=name, exact=True)


def heading(page, name):
    return page.get_by_role("heading", name=name, exact=True)


def open_scenario(page, url, scenario):
    page.goto(f"{url}?scenario={scenario}")
    expect(heading(page, "Способы получения")).to_be_visible()


def check_card_prices(page):
    for label, fee, total in (("Самовывоз", 0, "1 590"), ("Курьер", 249, "1 839")):
        card = page.get_by_role("article", name=label, exact=True)
        line = card.get_by_text(f"Итого с товаром {total} ₽", exact=True)
        if line.count() != 1:
            raise AssertionError(f"{label}: на экране выбора нет полной суммы {total} ₽.")
        expect(line).to_be_visible()
        expect(card.get_by_text(f"Получение {fee} ₽", exact=True)).to_be_visible()


def main_case(page, url, screens):
    open_scenario(page, url, "ready")
    check_card_prices(page)
    expect(page.get_by_text("Сегодня, 17:30–19:00", exact=True)).to_be_visible()
    expect(page.get_by_text("Сегодня, 16:00–18:00", exact=True)).to_be_visible()
    expect(page.get_by_text("Позже нужного срока", exact=True)).to_have_count(0)
    if screens:
        page.locator(".shell").screenshot(path=screens / "01-ready.png")
    button(page, "Выбрать самовывоз").click()
    expect(heading(page, "Проверьте получение")).to_be_visible()
    expect(page.get_by_text("Итого 1 590 ₽", exact=True)).to_be_visible()
    button(page, "Изменить способ").click()
    expect(button(page, "Выбрать самовывоз")).to_be_focused()
    button(page, "Выбрать самовывоз").click()
    button(page, "Подтвердить в демо").click()
    expect(heading(page, "Способ подтверждён")).to_be_visible()
    expect(page.get_by_text("Самовывоз · 1 590 ₽ итого", exact=True)).to_be_visible()
    expect(page.get_by_text("Сегодня, 17:30–19:00 · Лесная ул., 12 · тестовая точка", exact=True)).to_be_visible()


def alternative_case(page, url, screens):
    open_scenario(page, url, "late")
    check_card_prices(page)
    expect(page.get_by_text("Позже нужного срока", exact=True)).to_have_count(1)
    if screens:
        page.locator(".shell").screenshot(path=screens / "02-courier.png")
    button(page, "Выбрать самовывоз").click()
    expect(page.get_by_text("Получение позже вашего срока.", exact=True)).to_be_visible()
    button(page, "Изменить способ").click()
    button(page, "Выбрать курьер").click()
    expect(page.get_by_text("Итого 1 839 ₽", exact=True)).to_be_visible()
    button(page, "Подтвердить в демо").click()
    expect(heading(page, "Способ подтверждён")).to_be_visible()
    expect(page.get_by_text("Курьер · 1 839 ₽ итого", exact=True)).to_be_visible()
    expect(page.get_by_text("Сегодня, 17:00–19:00 · Садовая ул., 21 · тестовый адрес", exact=True)).to_be_visible()


def boundary_case(page, url, screens):
    open_scenario(page, url, "unknown")
    expect(page.get_by_text("Время уточняется", exact=True)).to_be_visible()
    expect(button(page, "Выбрать самовывоз")).to_be_disabled()
    expect(button(page, "Подтвердить в демо")).to_have_count(0)
    if screens:
        page.locator(".shell").screenshot(path=screens / "03-unknown.png")
    retry = button(page, "Проверить доступность")
    if retry.count() == 0:
        raise AssertionError("Самовывоз заблокирован, но на экране нет действия для повторной проверки.")
    explanation = page.get_by_text("Цена рассчитана, окно выдачи пока не подтверждено.", exact=False)
    if explanation.count() == 0:
        raise AssertionError("Нет различия между рассчитанной ценой и неподтверждённым окном.")
    expect(explanation).to_be_visible()

    retry.click()
    expect(page.get_by_text("Окно всё ещё не подтверждено.", exact=True)).to_be_visible()
    expect(button(page, "Выбрать самовывоз")).to_be_disabled()
    expect(retry).to_be_focused()
    expect(button(page, "Подтвердить в демо")).to_have_count(0)
    retry.click()
    expect(page.get_by_text("Сегодня, 18:10–19:00", exact=True)).to_be_visible()
    expect(button(page, "Подтвердить в демо")).to_have_count(0)
    expect(button(page, "Выбрать самовывоз")).to_be_focused()
    button(page, "Выбрать самовывоз").click()
    button(page, "Подтвердить в демо").click()
    expect(heading(page, "Способ подтверждён")).to_be_visible()
    expect(page.get_by_text("Сегодня, 18:10–19:00 · Лесная ул., 12 · тестовая точка", exact=True)).to_be_visible()

    open_scenario(page, url, "unknown")
    button(page, "Вернуться в корзину").click()
    expect(heading(page, "Корзина")).to_be_visible()
    button(page, "Снова сравнить способы").click()
    expect(heading(page, "Способы получения")).to_be_visible()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prototype", type=Path, default=Path(__file__).with_name("prototype.html"))
    parser.add_argument("--screens", type=Path)
    parser.add_argument("--chromium", default="/usr/bin/chromium")
    args = parser.parse_args()
    failures = 0
    if args.screens:
        args.screens.mkdir(parents=True, exist_ok=True)
    with serve(args.prototype.resolve()) as url, sync_playwright() as browser_api:
        browser = browser_api.chromium.launch(executable_path=args.chromium, args=["--no-sandbox"])
        page = browser.new_page(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True)
        errors = []
        page.on("pageerror", lambda error: errors.append(str(error)))
        expect.set_options(timeout=2500)
        print(f"Chromium {browser.version} | {args.prototype.name} | 390×844")
        for name, case in (("A / самовывоз", main_case), ("B / курьер", alternative_case), ("C / окно неизвестно", boundary_case)):
            try:
                case(page, url, args.screens)
                print(f"PASS | {name}")
            except AssertionError as error:
                failures += 1
                print(f"FAIL | {name} | {str(error).splitlines()[0]}")
        page.set_viewport_size({"width": 320, "height": 760})
        open_scenario(page, url, "unknown")
        overflow = page.evaluate("document.documentElement.scrollWidth > innerWidth")
        if errors or overflow:
            failures += 1
            print(f"FAIL | D / 320 px | overflow={overflow}; JS errors={errors}")
        else:
            print("PASS | D / 320 px без горизонтальной прокрутки и ошибок JavaScript")
        browser.close()
    raise SystemExit(bool(failures))


if __name__ == "__main__":
    main()

"""Generate the synthetic event log and listing dictionary."""

import csv
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

SEED = 46291
ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
START = datetime(2026, 10, 1, tzinfo=timezone.utc)
CUTOFF = datetime(2026, 10, 15, tzinfo=timezone.utc)
EVENT_FIELDS = (
    "row_id", "event_id", "session_id", "event_type", "listing_id",
    "event_at_utc", "device", "channel", "case_id",
)
LISTING_FIELDS = ("listing_id", "category")


def save_csv(path, fields, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(fields)
        writer.writerows(rows)


def generate():
    data_random = random.Random(SEED)
    listings = [
        (f"L{index:03}", category)
        for index, category in enumerate(
            ("Математика", "Экономика", "Языки", "Программирование") * 8, 1
        )
    ]
    listing_ids = [listing_id for listing_id, _ in listings]
    events = []

    def record(session, device, channel, path, case=""):
        for event_time, name, listing in path:
            ordinal = len(events) + 1
            if name == "duplicate":
                events.append((ordinal, *events[-1][1:]))
                continue
            events.append(
                (ordinal, f"E{ordinal:05}", session, name, listing,
                 event_time.isoformat(timespec="seconds"), device, channel, case)
            )

    for index in range(1, 1033):
        device = "mobile" if index <= 650 or 1001 <= index <= 1020 else "desktop"
        channel = data_random.choice(("organic", "direct", "referral"))
        listing, second = data_random.sample(listing_ids, 2)
        if index > 1000:
            began = CUTOFF - timedelta(hours=6, minutes=data_random.randrange(120))
        else:
            began = START + timedelta(minutes=data_random.randrange(12 * 24 * 60))
        p_view, p_contact, p_deal = (0.79, 0.31, 0.62) if device == "mobile" else (0.83, 0.51, 0.60)
        path = [(began, "search", "")]
        if data_random.random() < p_view:
            path.append((began + timedelta(minutes=4), "listing_view", listing))
            if data_random.random() < 0.33:
                path.append((began + timedelta(minutes=8), "listing_view", second))
            if data_random.random() < p_contact:
                path.append((began + timedelta(minutes=12), "contact", listing))
                if data_random.random() < p_deal:
                    path.append((began + timedelta(hours=2), "deal_agreed", listing))
        record(f"S{index:04}", device, channel, path)

    def diagnostic(index, suffix, *, start=START + timedelta(days=1), device="mobile"):
        case = f"QC-{index:02}"
        if index % 2 == 0:
            device = "desktop"
        events_in_case = [(start, "search", "")]
        for minutes, kind, listing in suffix:
            events_in_case.append((start + timedelta(minutes=minutes), kind, listing))
        record(case, device, "direct", events_in_case, case)

    first, second = listing_ids[:2]
    diagnostic(1, [(5, "listing_view", first), (8, "contact", first),
                   (8, "duplicate", first), (10, "deal_agreed", first)])
    diagnostic(2, [(2, "listing_view", second), (5, "listing_view", first),
                   (8, "listing_view", second), (10, "contact", first),
                   (12, "deal_agreed", first)])
    diagnostic(3, [(5, "listing_view", first), (8, "contact", second),
                   (10, "deal_agreed", second)])
    diagnostic(4, [(2, "contact", first), (5, "listing_view", first),
                   (8, "deal_agreed", first)])
    diagnostic(5, [(2, "listing_view", first), (5, "deal_agreed", first),
                   (8, "contact", first)])
    diagnostic(6, [(2, "listing_view", first), (5, "contact", first),
                   (8, "deal_agreed", first)], start=CUTOFF - timedelta(hours=2))
    diagnostic(7, [(5, "listing_view", first), (8, "contact", first),
                   (1440, "deal_agreed", first)])
    diagnostic(8, [(5, "listing_view", first), (5, "contact", first)])
    diagnostic(9, [(5, "listing_view", first), (8, "contact", first),
                   (1439, "deal_agreed", first)], start=CUTOFF - timedelta(days=1))
    diagnostic(10, [(5, "listing_view", first), (8, "contact", first),
                    (10, "deal_agreed", first), (15, "listing_view", second),
                    (18, "contact", second), (20, "deal_agreed", second)])
    diagnostic(11, [(5, "listing_view", first), (8, "contact", first),
                    (10, "deal_agreed", second)])
    diagnostic(12, [(5, "listing_view", first), (8, "search", ""),
                    (10, "contact", first), (12, "deal_agreed", first)])
    diagnostic(13, [(-5, "listing_view", first), (8, "contact", first),
                    (10, "deal_agreed", first)])

    DATA.mkdir(exist_ok=True)
    save_csv(DATA / "events.csv", EVENT_FIELDS, events)
    save_csv(DATA / "listings.csv", LISTING_FIELDS, listings)
    print(f"Synthetic dataset, seed {SEED}: {len(events)} physical rows, {len(listings)} listings")


if __name__ == "__main__":
    generate()

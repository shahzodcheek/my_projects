"""Build the styled XLSX and optionally store values recalculated by Calc."""

import argparse
import shutil
import subprocess
import tempfile
from pathlib import Path

from openpyxl import Workbook
from openpyxl.pivot.cache import (
    CacheDefinition, CacheField, CacheSource, Number, SharedItems, Text, WorksheetSource,
)
from openpyxl.pivot.record import Index as CacheIndex, Record, RecordList
from openpyxl.pivot.table import (
    DataField, FieldItem, Index, Location, PivotField, PivotTableStyle, RowColField,
    RowColItem, TableDefinition,
)
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from checks import CASES, FLAGS, ROOT, STAGES, read_csv

NAVY = "163348"
TEAL = "04786F"
INK = "24475B"
ACCENT = "D8F4EF"
PALE = "F1F6F8"
WHITE = "FFFFFF"
PERCENT = "0.00%"


def fill(color):
    return PatternFill("solid", fgColor=color)


def merged(sheet, area, value, *, size=11, color=INK, bg=WHITE, bold=False, height=28):
    sheet.merge_cells(area)
    cell = sheet[area.split(":")[0]]
    cell.value = value
    cell.fill = fill(bg)
    cell.font = Font(name="Calibri", size=size, bold=bold, color=color)
    cell.alignment = Alignment(vertical="center", wrap_text=True, indent=1)
    sheet.row_dimensions[cell.row].height = height
    return cell


def make_sheet(book, name, title, subhead, widths):
    sheet = book.create_sheet(name)
    sheet.sheet_view.showGridLines = False
    sheet.sheet_properties.tabColor = TEAL if name in ("Выводы", "Воронка", "Сводная") else "9BAAB4"
    for col, width in enumerate(widths, 1):
        sheet.column_dimensions[get_column_letter(col)].width = width
    end_col = get_column_letter(len(widths))
    merged(sheet, f"A1:{end_col}2", title, size=20, color=WHITE, bg=NAVY, bold=True)
    merged(sheet, f"A3:{end_col}3", subhead, color=TEAL, bg=ACCENT, height=32)
    return sheet


def grid(sheet, header_row, headers, rows):
    for col, label in enumerate(headers, 1):
        cell = sheet.cell(header_row, col, label)
        cell.font = Font(name="Calibri", color=WHITE, bold=True, size=11)
        cell.fill = fill(NAVY)
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    sheet.row_dimensions[header_row].height = 32
    for row_no, data in enumerate(rows, header_row + 1):
        for col_no, val in enumerate(data, 1):
            cell = sheet.cell(row_no, col_no, val)
            cell.font = Font(name="Calibri", color=TEAL if cell.data_type == "f" else INK, size=11)
            cell.fill = fill(PALE if row_no % 2 == 0 else WHITE)
            cell.alignment = Alignment(vertical="center")
    sheet.freeze_panes = f"B{header_row + 1}"


def filter_range(sheet, header_row):
    sheet.auto_filter.ref = f"A{header_row}:{get_column_letter(sheet.max_column)}{sheet.max_row}"


def add_overview(book):
    overview = make_sheet(
        book, "Выводы", "Как поиск учебников доходит до контакта",
        "Учебный мини-кейс · синтетические события · условная площадка объявлений",
        [11] * 9,
    )
    merged(overview, "A5:I5", "Где теряется больше всего поисковых сессий?", size=14, bold=True)
    merged(
        overview, "A6:I7",
        "Самый большой отток в модели — просмотр объявления → контакт. На мобильных "
        "устройствах переход заметно ниже. Разница задана параметрами генератора.",
        height=28,
    )
    for label, area, reference, metric, num_format in (
        ("Сессий без контакта после просмотра", "A9:C9", "A10:C10", "='Воронка'!K7", "0"),
        ("Просмотр → контакт", "D9:F9", "D10:F10", "='Воронка'!H7", PERCENT),
        ("Разница desktop − mobile", "G9:I9", "G10:I10",
         "=('Воронка'!H8-'Воронка'!H9)*100", '0.00" п.п."'),
    ):
        merged(overview, area, label, color=TEAL, bg=ACCENT, bold=True, height=40)
        cell = merged(overview, reference, metric, size=20, bg=PALE, bold=True, height=38)
        cell.number_format = num_format
    merged(overview, "A12:I12", "Следующая проверка", size=14, bold=True)
    merged(
        overview, "A13:I14",
        "На реальном логе сначала проверить разметку контакта и воспроизводимость разрыва по "
        "устройствам. При подтверждении проверить гипотезу, что заметная кнопка «Написать» "
        "поможет перейти от просмотра к контакту на мобильном устройстве.",
        height=30,
    )
    for row, label, details in (
        (16, "Воронка и Сводная", "Формульная сводка по сегментам и нативная PivotTable с абсолютными счётчиками."),
        (17, "События и Объявления", "Исходные данные, справочник и точный поиск категории по listing_id."),
        (18, "Сессии и Проверки", "Флаги PostgreSQL и 13 случаев с ожидаемыми и фактическими значениями."),
        (19, "Метод", "Синтетический журнал событий. Проверки цепочки учитывают объявление и окно наблюдения."),
    ):
        merged(overview, f"A{row}:C{row}", label, bold=True, bg=PALE, height=35)
        merged(overview, f"D{row}:I{row}", details, height=35)


def add_summary(book, session_end):
    sheet = make_sheet(
        book, "Воронка", "Формульная воронка",
        "Единица расчёта · уникальная поисковая сессия с полным окном наблюдения",
        [15, 13, 13, 13, 17, 15, 15, 15, 16, 16, 18],
    )
    devices = f"'Сессии'!$C$6:$C${session_end}"
    rows = []
    for row_no, segment in enumerate(("all", "desktop", "mobile"), 7):
        sums = []
        for col in "DEFG":
            ref = f"'Сессии'!${col}$6:${col}${session_end}"
            sums.append(f"=SUM({ref})" if segment == "all" else f"=SUMIFS({ref},{devices},$A{row_no})")
        segment_size = f"COUNTA({devices})" if segment == "all" else f"COUNTIF({devices},$A{row_no})"
        ratios = [f'=IF({den}{row_no}=0,"",{num}{row_no}/{den}{row_no})'
                  for num, den in zip("CDEE", "BCDB")]
        rows.append((segment, *sums, f"={segment_size}-B{row_no}", *ratios, f"=C{row_no}-D{row_no}"))
    grid(sheet, 6, (
        "Устройство", "Поиск", "Просмотр", "Контакт", "Договорённость", "Неполное окно",
        "Поиск → просмотр", "Просмотр → контакт", "Контакт → сделка", "Поиск → сделка",
        "Просмотр без контакта",
    ), rows)
    for row in range(7, 10):
        for col in range(7, 11):
            sheet.cell(row, col).number_format = PERCENT
        sheet.cell(row, 8).fill = fill(ACCENT)
        sheet.cell(row, 11).fill = fill(ACCENT)
    merged(
        sheet, "A12:K12",
        "Excel суммирует флаги с листа «Сессии». Строгий порядок событий и связь с одним объявлением вычисляет SQL.",
        height=27,
    )
    merged(
        sheet, "A13:K13",
        "Знаменатели последовательных переходов — предыдущие этапы. Для «Поиск → сделка» знаменатель — поиск.",
        height=27,
    )


def add_pivot(book, flags, totals):
    sheet = make_sheet(
        book, "Сводная", "Сводная таблица по устройствам",
        "Нативная PivotTable · четыре суммы флагов · обновление через меню сводной",
        [24, 20, 19, 19, 23],
    )
    fields = ("device", *FLAGS)
    devices = ("desktop", "mobile")
    categories = CacheField(name="device", sharedItems=SharedItems(_fields=[Text(v=x) for x in devices]))
    numbers = [
        CacheField(name=key, sharedItems=SharedItems(
            containsSemiMixedTypes=False, containsString=False, containsNumber=True,
            containsInteger=True, minValue=0, maxValue=1,
        ))
        for key in FLAGS
    ]
    cache = CacheDefinition(
        cacheSource=CacheSource(
            type="worksheet", worksheetSource=WorksheetSource(sheet="Сессии", ref=f"C5:G{len(flags) + 5}"),
        ),
        cacheFields=[categories, *numbers], recordCount=len(flags), saveData=True, refreshOnLoad=True,
        createdVersion=6, refreshedVersion=6, minRefreshableVersion=3,
    )
    cache.records = RecordList(r=[
        Record(_fields=[CacheIndex(v=devices.index(row["device"])), *(Number(v=int(row[key])) for key in FLAGS)])
        for row in flags
    ])
    labels = ("Поиск", "Просмотр", "Контакт", "Договорённость")
    pivot = TableDefinition(
        name="TextbookFunnelPivot", cacheId=1, dataCaption="Значения", grandTotalCaption="Все устройства",
        location=Location(ref="A5:E9", firstHeaderRow=1, firstDataRow=2, firstDataCol=1),
        pivotFields=[PivotField(axis="axisRow", items=[FieldItem(x=idx) for idx in range(2)] +
                                [FieldItem(t="default")])] + [PivotField(dataField=True) for _ in FLAGS],
        rowFields=[RowColField(x=0)],
        rowItems=[RowColItem(x=[Index(v=idx)]) for idx in range(2)] + [RowColItem(t="grand", x=[Index()])],
        colFields=[RowColField(x=-2)],
        colItems=[RowColItem(i=idx, x=[Index(v=idx)]) for idx in range(4)],
        dataFields=[DataField(name=label, fld=fields.index(key)) for key, label in zip(FLAGS, labels)],
        pivotTableStyleInfo=PivotTableStyle(name="PivotStyleMedium9", showRowHeaders=True, showColHeaders=True),
        createdVersion=6, updatedVersion=6, minRefreshableVersion=3,
    )
    pivot.cache = cache
    sheet.add_pivot(pivot)
    sheet["B5"] = "Значения"
    rows = [
        (device if device != "all" else "Все устройства", *(int(totals[device][key]) for key in STAGES))
        for device in (*devices, "all")
    ]
    grid(sheet, 6, ("Устройство", *labels), rows)
    merged(
        sheet, "A12:E12", "Источник · поля device и четыре флага с листа «Сессии». Единица · одна строка на сессию.",
        height=31,
    )


def add_controls(book, session_end, event_end):
    sheet = make_sheet(
        book, "Проверки", "Контрольные случаи",
        "Каждая строка проверяет ожидаемые флаги и фактические флаги SQL через формулы Excel.",
        [14, 13, 13, 13, 13, 13, 13, 13, 13, 13, 80],
    )
    merged(sheet, "B5:E5", "Ожидаемые флаги", bold=True, bg=ACCENT)
    merged(sheet, "F5:I5", "Фактические флаги", bold=True, bg=ACCENT)
    rows = []
    for row_no, (case, (expected, text)) in enumerate(CASES.items(), 7):
        refs = [f"=VLOOKUP($A{row_no},'Сессии'!$A$6:$I${session_end},{col},FALSE)" for col in range(4, 8)]
        matches = ",".join(f"{left}{row_no}={right}{row_no}" for left, right in zip("BCDE", "FGHI"))
        rows.append((case, *expected, *refs, f'=IF(AND({matches}),"OK","ПРОВЕРИТЬ")', text))
    steps = ("Поиск", "Просмотр", "Контакт", "Сделка")
    grid(sheet, 6, ("Сессия", *steps, *steps, "Итог", "Что проверяем"), rows)
    grid(
        sheet, 21, ("Диагностика", "Строки", "События", "Дубли"),
        [("Журнал", f"=COUNTA('События'!A6:A{event_end})", "=B22-D22",
          f"=SUM('События'!K6:K{event_end})")],
    )
    sheet.freeze_panes = "B7"


def build(path):
    book = Workbook()
    book.remove(book.active)
    book.properties.title = "Воронка поиска учебников · синтетические данные"
    book.properties.creator = ""

    events = read_csv("events.csv")
    listings = read_csv("listings.csv")
    flags = read_csv("session_flags.csv")
    totals = {row["device"]: row for row in read_csv("funnel_by_device.csv")}
    session_end, event_end, listing_end = len(flags) + 5, len(events) + 5, len(listings) + 5
    add_overview(book)
    add_summary(book, session_end)
    add_pivot(book, flags, totals)

    session_sheet = make_sheet(
        book, "Сессии", "Одна строка на поисковую сессию",
        "Флаги рассчитаны в PostgreSQL. eligible_search = 0 означает неполное окно.",
        [16, 30, 15, 16, 14, 14, 14, 15, 13],
    )
    grid(
        session_sheet, 5, ("session_id", "search_at_utc", "device", *FLAGS, "channel", "case_id"),
        [(item["session_id"], item["search_at_utc"], item["device"], *(int(item[key]) for key in FLAGS),
          item["channel"], item["case_id"] or None) for item in flags],
    )
    filter_range(session_sheet, 5)

    raw = make_sheet(
        book, "События", "Синтетический журнал событий",
        "Строки CSV без исправлений · категория и признак повторной строки посчитаны формулами Excel.",
        [12, 14, 15, 18, 14, 30, 13, 14, 13, 25, 15],
    )
    rows = []
    for row_no, row in enumerate(events, 6):
        category = (
            f'=IF(E{row_no}="","",IFERROR(VLOOKUP(E{row_no},\'Объявления\'!$A$6:$B${listing_end},'
            '2,FALSE),"Нет в справочнике"))'
        )
        duplicate = f"=IF(COUNTIF($B$6:B{row_no},B{row_no})>1,1,0)"
        rows.append((int(row["row_id"]), *(val or None for val in list(row.values())[1:]), category, duplicate))
    grid(raw, 5, (*events[0].keys(), "category", "copy_flag"), rows)
    filter_range(raw, 5)

    listing_sheet = make_sheet(
        book, "Объявления", "Справочник объявлений",
        "Синтетический listing_id · точный ключ поиска категории",
        [21, 86],
    )
    grid(listing_sheet, 5, ("listing_id", "category"), [tuple(row.values()) for row in listings])
    filter_range(listing_sheet, 5)

    add_controls(book, session_end, event_end)
    book.save(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--recalculate", action="store_true", help="Populate formula caches via LibreOffice Calc")
    parser.add_argument("--out", type=Path, default=ROOT / "funnel.xlsx")
    args = parser.parse_args()
    if not args.recalculate:
        build(args.out)
        return
    with tempfile.TemporaryDirectory(prefix="funnel-calc-") as tmp:
        base = Path(tmp)
        source = base / "funnel.xlsx"
        recalc = base / "recalculated"
        recalc.mkdir()
        build(source)
        subprocess.run(
            ["soffice", f"-env:UserInstallation={(base / 'profile').as_uri()}", "--headless",
             "--convert-to", "xlsx", "--outdir", str(recalc), str(source)],
            check=True, timeout=120,
        )
        shutil.copyfile(recalc / source.name, args.out)


if __name__ == "__main__":
    main()

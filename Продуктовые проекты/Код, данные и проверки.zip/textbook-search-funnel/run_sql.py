"""Run funnel.sql on native PostgreSQL and export all SQL outputs."""

import argparse
import os
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PSQL_ARGS = ["-X", "-v", "ON_ERROR_STOP=1", "-f", "funnel.sql"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dsn", help="Use an existing PostgreSQL instance and system psql")
    args = parser.parse_args()
    if args.dsn:
        subprocess.run(["psql", *PSQL_ARGS, "--dbname", args.dsn], cwd=ROOT, check=True)
        return

    with tempfile.TemporaryDirectory(prefix="funnel-pg-") as temp_dir:
        os.environ.setdefault("XDG_RUNTIME_DIR", temp_dir)
        from pgserver import get_server, psql

        with get_server(Path(temp_dir) / "pgdata") as server:
            output = psql([*PSQL_ARGS, "--dbname", server.get_uri()], cwd=ROOT)
        print(output, end="")


if __name__ == "__main__":
    main()

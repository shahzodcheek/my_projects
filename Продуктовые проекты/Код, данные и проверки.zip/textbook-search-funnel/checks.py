"""Validate SQL against an independent session walk and inspect the XLSX."""

import argparse
import csv
import math
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

from generate_data import CUTOFF, START

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
FLAGS = ("eligible_search", "view_flag", "contact_flag", "deal_flag")
STAGES = ("searches", "views", "contacts", "deals")
RATIOS = ("search_to_view", "view_to_contact", "contact_to_deal", "search_to_deal")

CASES = {
    "QC-01": ((1, 1, 1, 1), "Повтор event_id контакта. Один логический контакт, одна сессия."),
    "QC-02": ((1, 1, 1, 1), "Несколько просмотров. Для контакта находится нужное объявление."),
    "QC-03": ((1, 1, 0, 0), "Просмотр одного объявления, контакт и договорённость по другому."),
    "QC-04": ((1, 1, 0, 0), "Контакт раньше просмотра. Цепочка обрывается на просмотре."),
    "QC-05": ((1, 1, 1, 0), "Договорённость раньше контакта. Цепочка обрывается на контакте."),
    "QC-06": ((0, 0, 0, 0), "Полная цепочка видна, но за поиском наблюдали меньше 24 часов."),
    "QC-07": ((1, 1, 1, 0), "Договорённость ровно через 24 часа вне окна."),
    "QC-08": ((1, 1, 0, 0), "Одинаковое время просмотра и контакта. Порядок не подтверждён."),
    "QC-09": ((1, 1, 1, 1), "Конец 24-часового окна совпал с отсечкой. Сессия включена."),
    "QC-10": ((1, 1, 1, 1), "Две полные цепочки. Сессия учтена по одному разу на этап."),
    "QC-11": ((1, 1, 1, 0), "Договорённость по другому объявлению после валидного контакта."),
    "QC-12": ((1, 1, 1, 1), "Повторный поиск. Окно открывается от первого поиска."),
    "QC-13": ((1, 0, 0, 0), "Единственный просмотр был до первого поиска."),
}


def read_csv(name):
    with (DATA / name).open(encoding="utf-8", newline="") as file:
        return list(csv.DictReader(file))


def verify_sql():
    raw = read_csv("events.csv")
    listings = {r["listing_id"] for r in read_csv("listings.csv")}
    sessions = defaultdict(list)
    seen = {}
    for event in sorted(raw, key=lambda r: int(r["row_id"])):
        fields = {key: val for key, val in event.items() if key != "row_id"}
        if event["event_id"] in seen:
            assert seen[event["event_id"]] == fields, "Conflict in duplicate event"
            continue
        seen[event["event_id"]] = fields
        sessions[event["session_id"]].append(
            (datetime.fromisoformat(event["event_at_utc"]), event)
        )

    sql_flags = {r["session_id"]: r for r in read_csv("session_flags.csv")}
    assert set(sessions) == set(sql_flags)
    for session, timeline in sessions.items():
        timeline.sort(key=lambda item: (item[0], int(item[1]["row_id"])))
        started, search = next(
            (at, e) for at, e in timeline if e["event_type"] == "search" and START <= at < CUTOFF
        )
        end = started + timedelta(hours=24)
        paths = defaultdict(dict)
        if end <= CUTOFF:
            for at, event in timeline:
                listing = event["listing_id"]
                if not started < at < end or listing not in listings:
                    continue
                state = paths[listing]
                step = event["event_type"]
                if step == "listing_view":
                    state.setdefault("view", at)
                elif step == "contact" and "view" in state and state["view"] < at:
                    state.setdefault("contact", at)
                elif step == "deal_agreed" and "contact" in state and state["contact"] < at:
                    state.setdefault("deal", at)
        expected = (int(end <= CUTOFF), *(int(any(step in p for p in paths.values()))
                                        for step in ("view", "contact", "deal")))
        sql = sql_flags[session]
        assert tuple(int(sql[key]) for key in FLAGS) == expected, session
        assert datetime.fromisoformat(sql["search_at_utc"]) == started, session
        assert (sql["device"], sql["channel"]) == (search["device"], search["channel"]), session
        if session in CASES:
            assert expected == CASES[session][0], session
    assert set(CASES) <= set(sql_flags)

    totals = {r["device"]: r for r in read_csv("funnel_by_device.csv")}
    for segment, result in totals.items():
        rows = [r for r in sql_flags.values() if segment == "all" or r["device"] == segment]
        counts = [sum(int(r[key]) for r in rows) for key in FLAGS]
        assert counts == [int(result[key]) for key in STAGES], segment
        assert len(rows) - counts[0] == int(result["incomplete_windows"]), segment
        for key, (numerator, denominator) in zip(RATIOS, ((1, 0), (2, 1), (3, 2), (3, 0))):
            assert math.isclose(counts[numerator] / counts[denominator], float(result[key]),
                                abs_tol=5.1e-9), key
    diagnostic, = read_csv("diagnostics.csv")
    assert [int(n) for n in diagnostic.values()] == [len(raw), len(seen), len(raw) - len(seen), 0]
    print(f"SQL: {len(sessions)} sessions, {len(CASES)} named checks, 3 segments, {len(raw) - len(seen)} duplicate.")
    return totals


def verify_workbook(totals, path):
    from openpyxl import load_workbook

    formulas = load_workbook(path)
    cached = load_workbook(path, data_only=True)
    summary = cached["Воронка"]
    assert summary["C7"].value is not None, "Recalculate the XLSX before comparing cached results"
    for excel_row in range(7, 10):
        result = totals[summary.cell(excel_row, 1).value]
        for col, key in enumerate((*STAGES, "incomplete_windows", *RATIOS), 2):
            value = summary.cell(excel_row, col).value
            assert math.isclose(value, float(result[key]), abs_tol=5.1e-9), (key, value)
            assert formulas["Воронка"].cell(excel_row, col).data_type == "f"
    assert "SUMIFS" in formulas["Воронка"]["B8"].value
    assert all(summary.cell(row, 11).value == int(totals[summary.cell(row, 1).value]["views"]) -
               int(totals[summary.cell(row, 1).value]["contacts"]) for row in range(7, 10))
    assert cached["Выводы"]["A10"].value == 500
    assert math.isclose(cached["Выводы"]["G10"].value, (166 / 308 - 159 / 517) * 100, abs_tol=5.1e-7)

    dictionary = {r["listing_id"]: r["category"] for r in read_csv("listings.csv")}
    ids = set()
    for excel_row, source in enumerate(read_csv("events.csv"), 6):
        events = cached["События"]
        first = source["event_id"] not in ids
        assert events.cell(excel_row, 2).value == source["event_id"], excel_row
        assert events.cell(excel_row, 10).value in {dictionary.get(source["listing_id"]), ""}, excel_row
        if source["listing_id"]:
            assert events.cell(excel_row, 10).value == dictionary[source["listing_id"]], excel_row
        assert events.cell(excel_row, 11).value == int(not first), excel_row
        assert formulas["События"].cell(excel_row, 10).data_type == "f", excel_row
        ids.add(source["event_id"])
    assert "VLOOKUP" in formulas["События"]["J6"].value
    assert "COUNTIF" in formulas["События"]["K6"].value

    for excel_row, source in enumerate(read_csv("session_flags.csv"), 6):
        sheet = cached["Сессии"]
        assert sheet.cell(excel_row, 1).value == source["session_id"], excel_row
        assert [sheet.cell(excel_row, col).value for col in range(4, 8)] == [
            int(source[field]) for field in FLAGS
        ], excel_row
    control = cached["Проверки"]
    for excel_row, case in enumerate(CASES, 7):
        assert control.cell(excel_row, 1).value == case
        assert tuple(control.cell(excel_row, col).value for col in range(6, 10)) == CASES[case][0]
        assert control.cell(excel_row, 10).value == "OK", case
    assert [control.cell(22, col).value for col in range(2, 5)] == [2727, 2726, 1]

    native = formulas["Сводная"]
    pivot, = native._pivots
    assert pivot.cache.cacheSource.worksheetSource.sheet == "Сессии"
    assert len(pivot.dataFields) == 4
    assert all(field.subtotal == "sum" for field in pivot.dataFields)
    values = list(cached["Сводная"].values)
    expected = [[int(totals[device][key]) for key in STAGES] for device in ("desktop", "mobile", "all")]
    actual = [list(row[1:5]) for row in values if row[0] in {"desktop", "mobile", "Все устройства", "Total Result"}]
    assert actual == expected, (actual, expected)
    assert all(cell.data_type != "e" for sheet in cached.worksheets for row in sheet for cell in row)
    print("XLSX: formulas and recalculated values, seven sheets, 13 cases, native PivotTable, no cell errors.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sql-only", action="store_true")
    parser.add_argument("--xlsx", type=Path, default=ROOT / "funnel.xlsx")
    args = parser.parse_args()
    totals = verify_sql()
    if not args.sql_only:
        verify_workbook(totals, args.xlsx)

\set ON_ERROR_STOP on
SET TIME ZONE 'UTC';
SELECT version();

CREATE TEMP TABLE raw_events (
    row_id integer PRIMARY KEY,
    event_id text NOT NULL,
    session_id text NOT NULL,
    event_type text NOT NULL CHECK (event_type IN ('search', 'listing_view', 'contact', 'deal_agreed')),
    listing_id text,
    event_at_utc timestamptz NOT NULL,
    device text NOT NULL CHECK (device IN ('desktop', 'mobile')),
    channel text NOT NULL,
    case_id text
);

CREATE TEMP TABLE listings (
    listing_id text PRIMARY KEY,
    category text NOT NULL
);

\copy raw_events FROM 'data/events.csv' CSV HEADER
\copy listings FROM 'data/listings.csv' CSV HEADER

-- A repeated event_id represents one logical event. Retain its first physical row.
CREATE TEMP VIEW events_once AS
WITH ranked AS (
    SELECT *,
           row_number() OVER (PARTITION BY event_id ORDER BY row_id) AS copy_number
    FROM raw_events
)
SELECT row_id, event_id, session_id, event_type, listing_id, event_at_utc, device, channel, case_id
FROM ranked
WHERE copy_number = 1;

CREATE TEMP TABLE session_flags AS
WITH parameters AS (
    SELECT TIMESTAMPTZ '2026-10-01 00:00:00+00' AS observation_start,
           TIMESTAMPTZ '2026-10-15 00:00:00+00' AS observation_end,
           INTERVAL '24 hours' AS follow_up
),
searches AS (
    SELECT DISTINCT ON (e.session_id)
           e.session_id, e.event_at_utc AS search_at_utc, e.device, e.channel, e.case_id
    FROM events_once e
    CROSS JOIN parameters p
    WHERE e.event_type = 'search'
      AND e.event_at_utc >= p.observation_start
      AND e.event_at_utc < p.observation_end
    ORDER BY e.session_id, e.event_at_utc, e.row_id
),
cohort AS (
    SELECT s.*, s.search_at_utc + p.follow_up AS window_end,
           (s.search_at_utc + p.follow_up <= p.observation_end)::integer AS eligible_search
    FROM searches s
    CROSS JOIN parameters p
),
visible_listing_events AS (
    SELECT e.session_id, e.event_type, e.listing_id, e.event_at_utc, e.event_id
    FROM events_once e
    JOIN cohort s ON s.session_id = e.session_id AND s.eligible_search = 1
    JOIN listings l ON l.listing_id = e.listing_id
    WHERE e.event_at_utc > s.search_at_utc
      AND e.event_at_utc < s.window_end
),
views AS (
    SELECT session_id, listing_id, MIN(event_at_utc) AS viewed_at
    FROM visible_listing_events
    WHERE event_type = 'listing_view'
    GROUP BY session_id, listing_id
),
contacts AS (
    SELECT v.session_id, v.listing_id, MIN(e.event_at_utc) AS contacted_at
    FROM views v
    JOIN visible_listing_events e USING (session_id, listing_id)
    WHERE e.event_type = 'contact'
      AND e.event_at_utc > v.viewed_at
    GROUP BY v.session_id, v.listing_id
),
deals AS (
    SELECT DISTINCT c.session_id, c.listing_id
    FROM contacts c
    JOIN visible_listing_events e USING (session_id, listing_id)
    WHERE e.event_type = 'deal_agreed'
      AND e.event_at_utc > c.contacted_at
),
reached AS (
    SELECT v.session_id, 1 AS view_flag,
           MAX((c.contacted_at IS NOT NULL)::integer) AS contact_flag,
           MAX((d.listing_id IS NOT NULL)::integer) AS deal_flag
    FROM views v
    LEFT JOIN contacts c USING (session_id, listing_id)
    LEFT JOIN deals d USING (session_id, listing_id)
    GROUP BY v.session_id
)
SELECT s.session_id, s.search_at_utc, s.device, s.channel, s.eligible_search,
       COALESCE(r.view_flag, 0) AS view_flag,
       COALESCE(r.contact_flag, 0) AS contact_flag,
       COALESCE(r.deal_flag, 0) AS deal_flag,
       s.case_id
FROM cohort s
LEFT JOIN reached r USING (session_id);

CREATE TEMP VIEW funnel_by_device AS
WITH totals AS (
    SELECT COALESCE(device, 'all') AS device,
           SUM(eligible_search) AS searches, SUM(view_flag) AS views,
           SUM(contact_flag) AS contacts, SUM(deal_flag) AS deals,
           COUNT(*) FILTER (WHERE eligible_search = 0) AS incomplete_windows
    FROM session_flags
    GROUP BY GROUPING SETS ((), (device))
)
SELECT *,
       ROUND(views::numeric / NULLIF(searches, 0), 8) AS search_to_view,
       ROUND(contacts::numeric / NULLIF(views, 0), 8) AS view_to_contact,
       ROUND(deals::numeric / NULLIF(contacts, 0), 8) AS contact_to_deal,
       ROUND(deals::numeric / NULLIF(searches, 0), 8) AS search_to_deal
FROM totals;

CREATE TEMP VIEW diagnostics AS
SELECT (SELECT COUNT(*) FROM raw_events) AS physical_rows,
       (SELECT COUNT(*) FROM events_once) AS logical_events,
       (SELECT COUNT(*) FROM raw_events) - (SELECT COUNT(*) FROM events_once) AS copies_removed,
       (SELECT COUNT(*) FROM raw_events WHERE event_type IN ('listing_view', 'contact', 'deal_agreed')
        AND (listing_id IS NULL OR NOT EXISTS (
            SELECT 1 FROM listings l WHERE l.listing_id = raw_events.listing_id
        ))) AS missing_listing_rows;

\copy (SELECT * FROM session_flags ORDER BY session_id) TO 'data/session_flags.csv' CSV HEADER
\copy (SELECT * FROM funnel_by_device ORDER BY device) TO 'data/funnel_by_device.csv' CSV HEADER
\copy (SELECT * FROM diagnostics) TO 'data/diagnostics.csv' CSV HEADER
SELECT * FROM funnel_by_device ORDER BY device;
SELECT * FROM diagnostics;

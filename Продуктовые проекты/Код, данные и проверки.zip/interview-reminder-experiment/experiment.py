"""Generate a new synthetic run and estimate paired, store-level ITT effects."""
import argparse
import csv
import json
import math
import random
from pathlib import Path
from statistics import mean, stdev

from scipy.stats import norm, t

SEED = 20261119
PAIRS = 52
PER_STORE = 40
USEFUL_LIFT = 0.06
GUARDRAILS = {"complaint": 0.01, "opt_out": 0.02}
METRICS = ("attended_d14", *GUARDRAILS)


def simulate(seed):
    rng = random.Random(seed)
    stores, candidates = [], []
    for pair in range(1, PAIRS + 1):
        region = "R1" if pair <= PAIRS // 2 else "R2"
        common = rng.gauss(0.62, 0.067)
        historic_volume = rng.randint(13, 29)
        groups = ["A", "B"]
        rng.shuffle(groups)
        for index, group in enumerate(groups, 1):
            store_id = f"S{pair:02d}{index}"
            pre_n = historic_volume + rng.randint(-2, 2)
            attendance = max(0.12, min(0.88, common + rng.gauss(0, 0.025)))
            pre_events = sum(rng.random() < attendance for _ in range(pre_n))
            stores.append(dict(pair_id=pair, store_id=store_id, region=region,
                               group=group, pre_bookings=pre_n, pre_attended=pre_events))
            # Calibrate to 62% overall in A and +6 pp in B around the seed-free model center.
            active_probability = min(0.92, max(0.02, (attendance - 0.08 * 0.12 - 0.12 * 0.46) / 0.80))
            delivered_lift = 0.06 / (0.80 * 0.98)
            for number in range(1, PER_STORE + 1):
                # Status at the planned T-24h send is mutually exclusive.
                status_draw = rng.random()
                status = ("cancelled" if status_draw < 0.08 else
                          "rescheduled" if status_draw < 0.20 else "active")
                sent = int(group == "B" and status == "active")
                delivered = int(sent and rng.random() < 0.98)
                outcome_probability = {
                    "active": active_probability + delivered * delivered_lift,
                    "cancelled": 0.12,
                    "rescheduled": 0.46,
                }[status]
                candidates.append(dict(
                    candidate_id=f"{store_id}-{number:02d}", pair_id=pair, store_id=store_id,
                    group=group, original_slot_t24=status, sms_sent=sent,
                    sms_delivered=delivered, attended_d14=int(rng.random() < outcome_probability),
                    complaint=int(rng.random() < 0.004 + 0.003 * delivered),
                    opt_out=int(rng.random() < 0.008 + 0.007 * delivered),
                ))
    return stores, candidates


def analyze(stores, candidates):
    by_store = {store["store_id"]: [] for store in stores}
    for row in candidates:
        by_store[row["store_id"]].append(row)

    store_results = []
    pairs = {}
    for store in stores:
        rows = by_store[store["store_id"]]
        totals = {key: sum(row[key] for row in rows) for key in (*METRICS, "sms_sent", "sms_delivered")}
        result = dict(store, assigned=len(rows), **totals)
        store_results.append(result)
        pairs.setdefault(store["pair_id"], {})[store["group"]] = result

    groups = {group: [row for row in store_results if row["group"] == group] for group in ("A", "B")}
    totals = {group: sum(row["assigned"] for row in rows) for group, rows in groups.items()}
    results = []
    critical = t.ppf(0.975, len(pairs) - 1)
    for metric in METRICS:
        differences = [
            arms["B"][metric] / arms["B"]["assigned"] - arms["A"][metric] / arms["A"]["assigned"]
            for arms in pairs.values()
        ]
        effect = mean(differences)
        margin = critical * stdev(differences) / math.sqrt(len(differences))
        events = {group: sum(row[metric] for row in rows) for group, rows in groups.items()}
        results.append(dict(metric=metric, n_a=totals["A"], n_b=totals["B"],
                            events_a=events["A"], events_b=events["B"],
                            rate_a=events["A"] / totals["A"], rate_b=events["B"] / totals["B"],
                            effect=effect, ci_low=effect - margin, ci_high=effect + margin))

    balance = {}
    for group, rows in groups.items():
        cohort = [row for row in candidates if row["group"] == group]
        pre_n = sum(row["pre_bookings"] for row in rows)
        balance[group] = dict(
            stores=len(rows), candidates=totals[group], pre_bookings_per_store=pre_n / len(rows),
            pre_attendance=sum(row["pre_attended"] for row in rows) / pre_n,
            cancelled_t24=sum(row["original_slot_t24"] == "cancelled" for row in cohort),
            rescheduled_t24=sum(row["original_slot_t24"] == "rescheduled" for row in cohort),
            sms_sent=sum(row["sms_sent"] for row in rows),
            sms_delivered=sum(row["sms_delivered"] for row in rows),
        )
    return store_results, results, balance


def decision(results):
    primary, *guards = results
    if primary["ci_high"] < USEFUL_LIFT or any(
        row["ci_low"] >= GUARDRAILS[row["metric"]] for row in guards
    ):
        return "decline"
    if primary["effect"] >= USEFUL_LIFT and primary["ci_low"] > 0 and all(
        row["ci_high"] < GUARDRAILS[row["metric"]] for row in guards
    ):
        return "rollout_in_stages"
    return "revise_or_repeat"


def planning():
    p_a, p_b = 0.62, 0.68
    p_mean = (p_a + p_b) / 2
    centered = math.sqrt(2 * p_mean * (1 - p_mean))
    alternative = math.sqrt(p_a * (1 - p_a) + p_b * (1 - p_b))
    z = norm.ppf(0.975)
    independent_n = math.ceil(((z * centered + norm.ppf(0.8) * alternative) / USEFUL_LIFT) ** 2)
    rows = []
    for icc in (0, 0.02, 0.05):
        design_effect = 1 + (PER_STORE - 1) * icc
        effective_n = PAIRS * PER_STORE / design_effect
        signal = USEFUL_LIFT * math.sqrt(effective_n)
        power = norm.cdf((signal - z * centered) / alternative)
        power += norm.cdf((-signal - z * centered) / alternative)
        rows.append(dict(icc=icc, design_effect=design_effect,
                         stores_per_arm=math.ceil(independent_n * design_effect / PER_STORE),
                         approx_power=power))
    return dict(independent_n_per_arm=independent_n, sensitivity=rows)


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as file:
        csv_writer = csv.DictWriter(file, fieldnames=rows[0])
        csv_writer.writeheader()
        csv_writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("reproduced"))
    parser.add_argument("--seed", type=int, default=SEED)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    stores, candidates = simulate(args.seed)
    store_results, results, balance = analyze(stores, candidates)
    for name, rows in (("candidates", candidates), ("store_results", store_results), ("results", results)):
        write_csv(args.out / f"{name}.csv", rows)
    summary = dict(synthetic=True, seed=args.seed, pairs=PAIRS, planning=planning(),
                   decision=decision(results), balance=balance)
    (args.out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(summary["decision"])


if __name__ == "__main__":
    main()

# Код, данные и проверки

Отчёты доступны в основном README подборки. Здесь находятся синтетические данные, скрипты, инструкции по проверке и дополнительные материалы к двум прототипам.

- [Выбор между самовывозом и курьером](checkout-delivery-choice/README.md)
- [Выбор пункта выдачи](pickup-point-selection/README.md)
- [Воронка поиска учебников](textbook-search-funnel/README.md)
- [Напоминания о собеседовании в «Магните»](interview-reminder-experiment/README.md)

"""Воспроизводимая браузерная проверка четырёх экранов прототипа ПВЗ."""

import argparse
from contextlib import contextmanager
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from urllib.parse import quote

from playwright.sync_api import expect, sync_playwright

NEAR = "Семестровая ул., 4"
LATE = "Аудиторный пер., 12"
LATEST = "Сессийная наб., 7"


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, format_string, *args):
        pass


@contextmanager
def serve(path):
    handler = partial(QuietHandler, directory=str(path.parent))
    with ThreadingHTTPServer(("127.0.0.1", 0), handler) as server:
        thread = Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            yield f"http://127.0.0.1:{server.server_port}/{quote(path.name)}"
        finally:
            server.shutdown()
            thread.join()


def start(page, url, *, unavailable=False):
    page.goto(url + ("?scenario=unavailable" if unavailable else ""))
    expect(page.get_by_role("heading", name="Оформление")).to_be_visible()
    page.get_by_role("button", name="Выбрать пункт выдачи").click()
    expect(page.get_by_role("heading", name="Пункты выдачи")).to_be_visible()


def choose(page, address):
    page.get_by_role("button", name=f"Выбрать пункт {address}").click()
    expect(page.get_by_role("heading", name="Проверьте выбор")).to_be_visible()
    expect(page.get_by_role("heading", name=address)).to_be_visible()


def confirm(page, address):
    page.get_by_role("button", name="Подтвердить пункт").click()
    expect(page.get_by_role("heading", name="Пункт подтверждён")).to_be_visible()
    expect(page.get_by_role("heading", name=address)).to_be_visible()


def capture(page, folder, name):
    if folder:
        folder.mkdir(parents=True, exist_ok=True)
        page.screenshot(path=folder / f"{name}.png", full_page=True)


def unavailable_checks(page, url, folder):
    start(page, url, unavailable=True)
    expect(page.get_by_role("button", name=f"Выбрать пункт {NEAR}")).to_have_count(0)
    capture(page, folder, "02-unavailable")
    reason = page.get_by_text("Пункт временно не принимает новые заказы.")
    alternate = page.get_by_text("Ближайший доступный пункт", exact=True)
    failures = []
    if not reason.is_visible():
        failures.append("причина недоступности отсутствует")
    if not alternate.is_visible():
        failures.append("ближайшая доступная точка отдельно не выделена")
    choose(page, LATE)
    confirm(page, LATE)
    return failures


def change_checks(page, url, folder):
    start(page, url)
    choose(page, NEAR)
    page.get_by_role("button", name="Изменить пункт").click()
    focused = page.evaluate("document.activeElement.id")
    failures = []
    if focused != "option-semester":
        failures.append(f"фокус после возврата: {focused!r}, ожидается 'option-semester'")
    capture(page, folder, "03-change")
    if focused == "option-semester":
        page.keyboard.press("Tab")
        expect(page.locator("#option-auditorium")).to_be_focused()
    choose(page, LATEST)
    confirm(page, LATEST)
    expect(page.get_by_text(NEAR)).to_have_count(0)
    expect(page.get_by_text("Без примерки.", exact=False)).to_be_visible()
    capture(page, folder, "04-confirmed")
    page.get_by_role("button", name="Начать заново").click()
    expect(page.get_by_text("Пока не выбран", exact=False)).to_be_visible()
    return failures


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("prototype", nargs="?", type=Path,
                        default=Path(__file__).with_name("prototype.html"))
    parser.add_argument("--screens", type=Path)
    parser.add_argument("--chromium", default="/usr/bin/chromium")
    args = parser.parse_args()
    with serve(args.prototype.resolve()) as url, sync_playwright() as browser_api:
        browser = browser_api.chromium.launch(
            executable_path=args.chromium, args=["--no-sandbox"]
        )
        page = browser.new_page(viewport={"width": 390, "height": 844},
                                device_scale_factor=1, is_mobile=True, has_touch=True)
        console_errors = []
        page.on("pageerror", lambda error: console_errors.append(str(error)))
        print(f"Chromium {browser.version} | 390×844 | {args.prototype.name}")

        start(page, url)
        capture(page, args.screens, "01-choice")
        assert page.evaluate("document.documentElement.scrollWidth === innerWidth")
        choose(page, NEAR)
        expect(page.get_by_text("Ежедневно 10:00–20:00")).to_be_visible()
        confirm(page, NEAR)
        print("PASS | A | обычный выбор и подтверждение ближайшего ПВЗ")

        failures = []
        for case_id, title, check in (
            ("B", "недоступность ближайшей точки и выбор альтернативы", unavailable_checks),
            ("C", "возврат в список, смена решения и сброс", change_checks),
        ):
            defects = check(page, url, args.screens)
            if defects:
                failures.extend(defects)
                print(f"FAIL | {case_id} | {title} | {', '.join(defects)}")
            else:
                print(f"PASS | {case_id} | {title}")

        page.set_viewport_size({"width": 320, "height": 700})
        start(page, url, unavailable=True)
        assert page.evaluate("document.documentElement.scrollWidth === innerWidth")
        assert not console_errors, console_errors
        print("PASS | D | 320 px без горизонтальной прокрутки, ошибок JavaScript нет")
        browser.close()
    raise SystemExit(bool(failures))


if __name__ == "__main__":
    main()
